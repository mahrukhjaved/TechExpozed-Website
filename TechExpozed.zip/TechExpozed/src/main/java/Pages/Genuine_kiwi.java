package Pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Genuine_kiwi {
	WebDriver driver;

	By logo = By.className("img-fluid");
	By titleText = By.tagName("title");
	By homePage = By.tagName("Home");
	By designPage = By.tagName("Design");
	By servicesPage = By.tagName("Our services");
	By aboutPage = By.tagName("About");
	By contactusPage = By.tagName("Contact");
    By userName = By.name("name");
	By emailAddress = By.name("email");
	By companyName = By.name("company");
	By mobileNumber = By.name("mobile");
	By domainName = By.name("domain");
	By addButton = By.className("ht-btn ht-btn-md add_url black");
	By removeButton = By.className("ht-btn ht-btn-md delete_url red");
	By checkbox1 = By.id("agree");
	By checkbox2 = By.id("nzMade");
	By buynowButton = By.className("ht-btn ht-btn-md price_submit");
	By mailbox = By.linkText("info@techexpozed.co.nz");
	By phone1 = By.linkText("0800 TECHEX");
	By phone2 = By.linkText("045660999");
	By scrollButton = By.id("scroll-top");
	By paypalButton = By.xpath("//button[@class='close']");
	By creditcardButton = By.xpath("//button[@class='close']");
	By popupcloseButton = By.xpath("//button[@class='close']");
	By orderSummaryTitle = By.xpath("//h4[@class='modal-title']");

	public Genuine_kiwi(WebDriver driver)
	{
		this.driver= driver;

	}

	//Set name in textbox

	public void setuserName(String struserName) {

		driver.findElement(userName).sendKeys(struserName);

	}

	public void setemail(String stremail) {

		driver.findElement(emailAddress).sendKeys(stremail);

	}

	public void setcompany(String strcompany) {

		driver.findElement(companyName).sendKeys(strcompany);

	}
	public void setmobile(CharSequence[] mobile) {

		driver.findElement(mobileNumber).sendKeys(mobile);

	}

	public void setdomain(CharSequence[] domain) {

		driver.findElement(domainName).sendKeys(domain);

	}

	public void clickagreement() {

		driver.findElement( By.id("agree")).click();

	}	

	public void clicknzmade() {

		driver.findElement( By.id("nzMade")).click();

	}

	//click on Add button

	public void clickAdd() {

		driver.findElement( By.className("ht-btn ht-btn-md add_url black")).click();

	}

	//click on Remove button
	public void clickRemove() {

		driver.findElement( By.className("ht-btn ht-btn-md delete_url red")).click();

	}

	//click on buynow button

	public void clickBuynow() {

		driver.findElement( By.className("ht-btn ht-btn-md price_submit")).click();

	}

	//Get the title of order summary pop-up
	public String getOrderpagetitle() {

		return driver.findElement(orderSummaryTitle).getText();

	}
	
	//Get the title of Genuine kiwi page
		public String getGenuinekiwiPageTitle() {

			return driver.findElement(titleText).getText();

		}

	/**
	 * This POM method will be exposed in test case
	 */

	public void order_logo(String struserName, String stremail, String strcompany, CharSequence[] mobile, CharSequence[] domain) {
		//Fill Name

		this.setuserName(struserName);

		//Fill email

		this.setemail(stremail);

		//Fill company

		this.setcompany(strcompany);

		//Fill mobile

		this.setmobile(mobile);

		//Fill domain

		this.setdomain(domain);

		//Click Add button

		this.clickAdd();

		//Click Remove button

		this.clickRemove();

		//Click on agreement checkboxes

		this.clickagreement();
		this.clicknzmade();

		//Click buynow button

		this.clickBuynow();
	}


}
