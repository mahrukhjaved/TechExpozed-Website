package TestSuite1;


import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeTest;

import org.testng.annotations.Test;



public class Genuinekiwi_Test {
	public String baseUrl = "https://techexpozed.co.nz/genuine-kiwi.php";
	public WebDriver driver;



	// This method is to navigate genuinekiwi URL

	@BeforeTest

	public void setBaseUrl() {

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		driver = new FirefoxDriver();
		driver.get(baseUrl);
	}

	// This method is to verify genuinekiwi URL appear correct
	@Test

	public void test_Genuinekiwi_page_appear_correct() {

		String expectedTitle = "Techexpozed - 100% Genuine Kiwi";
		String actualTitle = driver.getTitle();

		//Verify Genuine kiwi page title

		Assert.assertEquals(actualTitle, expectedTitle);
	}

	//*@DataProvider(name="genuine_form_data")
	//	public Object GenuineKiwiData() {
	//		ReadExcelFile configuration = new ReadExcelFile("path of file");
	//		int rows = configuration.getRowCount(0);
	//		Object[][]form_credentilas =new Object[rows][2];
	//
	//		for (int i=0;i<=rows;i++)
	//		{
	//			form_credentilas[i][0] = config.getData(0,i,0);
	//			form_credentilas[i][0] = Config.getData(0,i,1);			

	//		}

	//		return form_credentilas;
	//	}
	@Test
	public void order_form(String username, String email, String company, CharSequence[] mobileNumber, String domain) 
	{
		// To fill order form


		driver.findElement(By.id("name")).sendKeys(username);
		driver.findElement(By.id("email")).sendKeys(email);
		driver.findElement(By.id("company")).sendKeys(company);
		driver.findElement(By.id("mobile")).sendKeys(mobileNumber);
		driver.findElement(By.id("domain")).sendKeys(domain);
		driver.findElement(By.id("agree")).click();
		driver.findElement(By.id("nzMade")).click();
		driver.findElement(By.xpath("//button[@class='ht-btn ht-btn-md price_submit']")).click();
	}  


	@AfterTest

	public void quit() {

		driver.close();

	}


}

